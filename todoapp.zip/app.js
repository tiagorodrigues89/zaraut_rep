const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const port = process.env.PORT || 80;

let todos = [];

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// API-Endpunkte
app.get('/api/todos', (req, res) => {
    res.json(todos);
});

app.post('/api/todos', (req, res) => {
    const todo = req.body;
    todos.push(todo);
    res.status(201).json(todo);
});

app.delete('/api/todos/:index', (req, res) => {
    const index = parseInt(req.params.index);
    if (index >= 0 && index < todos.length) {
        todos.splice(index, 1);
        res.sendStatus(204);
    } else {
        res.sendStatus(404);
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});