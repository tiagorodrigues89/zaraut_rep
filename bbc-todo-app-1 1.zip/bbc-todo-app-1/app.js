document.addEventListener('DOMContentLoaded', () => {
    const todoForm = document.getElementById('todo-form');
    const todoInput = document.getElementById('todo-input');
    const todoList = document.getElementById('todo-list');

    let todos = []; // In einer echten Anwendung würden diese vom Backend geladen

    function renderTodos() {
        todoList.innerHTML = '';
        todos.forEach((todo, index) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>${todo}</span>
                <button class="delete-btn" data-index="${index}">Löschen</button>
            `;
            todoList.appendChild(listItem);
        });

        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const indexToDelete = parseInt(this.dataset.index);
                todos.splice(indexToDelete, 1);
                renderTodos();
                // In einer echten Anwendung würde hier ein Request an das Backend zum Löschen erfolgen
            });
        });
    }

    todoForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const newTodo = todoInput.value.trim();
        if (newTodo !== '') {
            todos.push(newTodo);
            renderTodos();
            todoInput.value = '';
            // In einer echten Anwendung würde hier ein Request an das Backend zum Speichern erfolgen
        }
    });

    // Simulieren des initialen Ladens von To-Dos vom Backend
    // In einer echten Anwendung würde hier ein Fetch-Aufruf erfolgen
    todos = ["Einkaufen gehen", "Bericht schreiben", "Meeting vorbereiten"];
    renderTodos();
});